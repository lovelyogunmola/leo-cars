LEO CARS — PHOTO UPLOAD PACK

Contains 9 photos:
- lexus-nx-rear.jpg
- lexus-nx-front-seats.jpg
- lexus-nx-sunroof-front-seats.jpg
- lexus-nx-front.jpg
- lexus-nx-rear-seats.jpg
- chevrolet-suburban-front.jpg
- chevrolet-suburban-rear.jpg
- chevrolet-suburban-dashboard.jpg
- chevrolet-suburban-interior.jpg

HOW TO ADD THESE TO THE WEBSITE
1. Extract/unzip this folder on your phone or computer.
2. Open https://github.com/lovelyogunmola/leo-cars
3. Choose Add file > Upload files.
4. Upload the 9 JPG files. If possible, upload them into an "images" folder.
5. Enter commit message: Add vehicle photos.
6. Commit changes.

IMPORTANT
Uploading the photos to GitHub stores them in the repository, but they will not automatically appear on the website. The website HTML must reference the image filenames, for example:
<img src="images/lexus-nx-front.jpg" alt="Lexus NX front view">

If you upload them in the repository root instead of an images folder, use:
<img src="lexus-nx-front.jpg" alt="Lexus NX front view">
